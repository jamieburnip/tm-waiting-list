export const waitingList = "/api/waiting-list";
